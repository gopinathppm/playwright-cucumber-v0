export const config = {
    // Specify global settings
    use: {
        headless: false,   // Whether to run in headless mode
        slowMo: 0,       // Slow down the execution by 100ms
        args: ['--start-maximized'], // Use this argument to start the browser maximized
        browserName: 'chromium', // You can set it to 'chromium', 'firefox', or 'webkit'
    },

    // Add the Allure reporter configuration
    reporter: [
        ['line'],
        ['allure-playwright', {
            outputFolder: 'allure-results',  // Directory where Allure results will be saved
        }],
    ],

    // Optionally, specify any global timeout settings
    timeout: 60000, // Set a global timeout of 60 seconds for tests
};