module.exports = {
    default: {
        require: ["src/step-definition/**/*.ts"],
        format: ["progress"],
        paths: ["src/test/features/**/*.feature"],
        requireModule: ["ts-node/register"],
        // format: [
        //     'json:reports/test-results/cucumber-report.json', // Generate JSON report
        // ],
    },
};