import reporter from 'cucumber-html-reporter';

const options = {
  theme: "bootstrap" as const,
  jsonFile: './reports/test-results/cucumber-report.json',
  output: './reports/test-results/cucumber-report.html',
  reportSuiteAsScenarios: true,
  launchReport: true,
  metadata: {
    "App Version": "1.0.0",
    "Test Environment": "SIT",
    "Browser": "Chrome",
    "Platform": "Windows 11",
    "Parallel": "Scenarios",
    "Executed": "Local"
  }
};

reporter.generate(options);