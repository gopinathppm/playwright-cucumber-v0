import { After, AfterStep, Before, BeforeAll } from '@cucumber/cucumber';
import { Browser, Page, BrowserContext, chromium } from 'playwright';
import * as dotenv from 'dotenv';
import { config } from './playwright.config';
import path from 'path';
import fs from 'fs';

dotenv.config();

let browser: Browser;
const screenshotPaths: Record<string, string[]> = {};


if (!process.env.NODE_ENV?.includes('API')) {

    Before(async function () {
        browser = await chromium.launch(config.use);
        const context: BrowserContext = await browser.newContext({ viewport: null });
        // const context: BrowserContext = await BrowserFactory.createBrowser('chromium');
        const page: Page = await context.newPage();
        this.page = page;
        this.context = context;
    });

    After(async function () {
        await this.context.close();
        await browser.close();
    });

    BeforeAll(async () => {
        const directoriesToClean = ['reports/Accessibility', 'reports/screenshots'];

        directoriesToClean.forEach((directory) => {
            const dirPath = path.join(__dirname, directory);
            if (fs.existsSync(dirPath)) {
                fs.readdirSync(dirPath).forEach((file) => {
                    const filePath = path.join(dirPath, file);
                    if (fs.lstatSync(filePath).isFile()) {
                        fs.unlinkSync(filePath);
                        console.log(`Deleted file: ${filePath}`);
                    }
                });
            } else {
                console.log(`Directory ${directory} does not exist.`);
            }
        });
    });

    AfterStep(async function ({ result, pickle }) {
        if ((result as { status?: string })?.status === 'FAILED') {
            try {
                const screenshotDir = './reports/screenshots';
                if (!fs.existsSync(screenshotDir)) {
                    fs.mkdirSync(screenshotDir, { recursive: true });
                }
                const screenshotPath = path.join(screenshotDir, `${pickle.name.replace(/\s+/g, '_')}.png`);

                if (this.page) {
                    await this.page.screenshot({ path: screenshotPath, fullPage: true });
                    console.log(`Screenshot saved for failed step: ${screenshotPath}`);

                    // Store the step-level screenshot path
                    if (!screenshotPaths[pickle?.name]) {
                        screenshotPaths[pickle?.name] = [];
                    }
                    screenshotPaths[pickle?.name].push(screenshotPath);
                } else {
                    console.error('Page object is not available to capture screenshot.');
                }
            } catch (error: any) {
                console.error(`Error capturing screenshot: ${error.message}`);
            }
        }
    });
}

// Exporting the hooks
export { Before, After };