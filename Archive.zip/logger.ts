import * as log4js from 'log4js';

// Load the configuration from the log4js.json file
log4js.configure('./log4js.json');

// Create a logger instance
const logger = log4js.getLogger();

export default logger;