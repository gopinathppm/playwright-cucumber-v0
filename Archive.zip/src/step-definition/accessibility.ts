import { Given, Then } from "@cucumber/cucumber";
import '../../hooks';
import { generateFinalHtmlReport, validateAccessibility } from "../utils/commonFunctions";

Given('I call Accessibility report check', async function () {
    await validateAccessibility(this.page, ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']);
});

Then('I generate the final Accessibility report', async function () {
    generateFinalHtmlReport();
});