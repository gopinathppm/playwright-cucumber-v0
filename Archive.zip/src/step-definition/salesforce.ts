import { setDefaultTimeout, Then, When } from '@cucumber/cucumber';
import { expect } from 'playwright/test';
import { POManager } from '../pageFactory/poManager';
import { parsedJsonData } from '../utils/excelOperation';
import '../../hooks';
const DEFAULT_TIMEOUT = 30000;
setDefaultTimeout(DEFAULT_TIMEOUT);

let poManager: POManager;

When(/^I click on "([^"]*)" and enter "([^"]*)"$/, async function (args1, args2) {
    poManager = new POManager(this.page);
    await poManager.getCreateCasePage().appLauncher.click();
    await poManager.getCreateCasePage().searchBox.fill("cases");
    await this.page.waitForTimeout(2000);
});

Then(/^I should see search result for "([^"]*)" and select the item$/, async function (args1) {
    await poManager.getCreateCasePage().searchBox.press("Enter");
    return true;
});

Then(/^I navigate to the "([^"]*)" screen and save "([^"]*)" case without any details$/, async function (args1, args2) {
    await poManager.getCreateCasePage().selectNewcase.click();
    await poManager.getCreateCasePage().getButton.click();
    return true;
});

Then(/^I should see "([^"]*)" error message visible on the screen$/, async function (errorMessage) {
    await expect(poManager.getCreateCasePage().errorMessage(errorMessage)).toBeVisible();
    return true;
});

When(/^I login to "([^"]*)" application with "([^"]*)" and "([^"]*)"$/, async function (url, username, pwd) {
    poManager = new POManager(this.page);
    await poManager.getSFLoginPage().userName.fill(parsedJsonData.Username);
    await poManager.getSFLoginPage().password.fill(parsedJsonData.Password);
    await poManager.getSFLoginPage().login.click();
    return true;
});

Then(/^I should see "([^"]*)" visible on the screen$/, async function (value) {
    await expect(poManager.getSFLoginPage().welcomeMessage(value)).toBeVisible({ timeout: 30000 });
});