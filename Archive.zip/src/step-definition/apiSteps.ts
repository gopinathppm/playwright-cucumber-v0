import apiMethods from '../utils/commonApiCalls';
import { Given, Then, When, setDefaultTimeout } from '@cucumber/cucumber';
import * as apiTestData from '../dataFactory/test_data/API/apiTestDataIndex';
import { expect } from '@playwright/test'
import '../../hooks';
import { title } from 'process';

let url = 'https://jsonplaceholder.typicode.com/posts';
let headers = { 'Content-Type': 'application/json' }

Given(/^I make a POST call to "([^"]*)" to the catalogue$/, async (product: keyof typeof apiTestData) => {
    let url = 'https://jsonplaceholder.typicode.com/posts';
    let headers = { 'Content-Type': 'application/json' }

    // let response = await apiMethods.makePostRequest(apiTestData[product], url, headers);
    // expect(response.status()).toBe(201);
    // console.log('Response Body:', await response.json());

    apiMethods.makePostRequest(apiTestData[product], url, headers)
    .then(response => {
        expect(response.status()).toBe(201);
        return response.json();  // Return a promise to parse the JSON body
    })
    .then(responseBody => {
        console.log('Response Body:', responseBody);  // Handle the resolved JSON data
    })
    .catch(error => {
        console.error('Error making POST request:', error);
    });
});


Given(/^I make a GET call to validate all the users$/, async () => {
    let url = 'https://jsonplaceholder.typicode.com/posts/1';
    let headers = { 'Content-Type': 'application/json' }


    apiMethods.makeGetRequest(url, headers)
    .then(response => {
        expect(response.status()).toBe(200);
        return response.json();  // Return a promise to parse the JSON body
    })
    .then(responseBody => {
        console.log('Response Body:', responseBody);  // Handle the resolved JSON data
        expect(responseBody.title).toEqual('sunt aut facere repellat provident occaecati excepturi optio reprehenderit');
    })
    .catch(error => {
        console.error('Error making GET request:', error);
    });
});
