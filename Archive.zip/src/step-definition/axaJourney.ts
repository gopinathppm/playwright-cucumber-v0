import { Given, Then, When, setDefaultTimeout } from '@cucumber/cucumber';
import { POManager } from '../pageFactory/poManager';
import { parsedJsonData } from '../utils/excelOperation';
import { clickAndWaitForNewPage, writeToInputFile } from '../utils/commonFunctions';
import { getBaseUrl } from '../configs/envManager.conf';
import { expect } from '@playwright/test'
import '../../hooks';

const DEFAULT_TIMEOUT = 30000;
setDefaultTimeout(DEFAULT_TIMEOUT);
let poManager: POManager;

Given('I navigate to the home page', async function () {
    await this.page.goto(getBaseUrl())
    poManager = new POManager(this.page);
});

Then(/^I click '(.+)' button$/, async function (buttonName) {
    const button = poManager.getCommonPage().getButton(buttonName);
    if (button) {
        await button.waitFor({ state: 'visible' });
        await button.click();
    }
});

Then('I select quote for Heath Insurance', async function () {
    this.page = await clickAndWaitForNewPage(this.page, this.context, poManager.getHomePage().healthInsuranceQuote);
    poManager = new POManager(this.page);
});

Then('I select quote for Car Insurance', async function () {
    await poManager.getHomePage().carInsuranceQuote.click();
});

Then('I provide personal details', async function () {
    await this.page.waitForTimeout(10000);
    await poManager.getQuotePage().title.selectOption(parsedJsonData.Title)
    await poManager.getQuotePage().firstName.fill(parsedJsonData.First_Name)
    await poManager.getQuotePage().lastName.fill(parsedJsonData.Last_Name)
    const dob = await parsedJsonData.DOB.split('-')
    await poManager.getQuotePage().birthDay.selectOption(dob[0])
    await poManager.getQuotePage().birthMonth.selectOption(dob[1])
    await poManager.getQuotePage().birthYear.selectOption(dob[2])
});

Then('I fill contact details', async function () {
    await poManager.getQuotePage().emailAddress.fill(parsedJsonData.Email_Address)
    await poManager.getQuotePage().mobile.fill(parsedJsonData.Mobile.toString())
});

Then('I provide address details', async function () {
    await poManager.getQuotePage().postCode.fill(parsedJsonData.Postcode)
    await poManager.getCommonPage().getButton('Find address').click()
    await poManager.getQuotePage().searchedAddress.waitFor({ state: 'visible' })
    await poManager.getQuotePage().searchedAddress.selectOption(parsedJsonData.Home_Address);
    await poManager.getQuotePage().county.fill(parsedJsonData.County)
});

Then('I select the cover start date', async function () {
    const covStartDate = await parsedJsonData.Cover_Start_Date.split('-')
    await poManager.getQuotePage().coverDay.selectOption(covStartDate[0])
    await poManager.getQuotePage().coverMonth.selectOption(covStartDate[1])
    await poManager.getQuotePage().coverYear.selectOption(covStartDate[2])
});

Then(/^I fill '(.+)' for previous medical conditions$/, async function (answer: string) {
    await poManager.getQuotePage().medicalCondition(answer.toLocaleLowerCase()).click();
});

Then(/^I fill '(.+)' for tobacco user$/, async function (answer: string) {
    await poManager.getQuotePage().tobaccoUse(answer.toLocaleLowerCase()).click();
});

When('I select acknowledgment', async function () {
    await poManager.getQuotePage().authID.click()
});

Then(/^I should be taken to page as '(.+)'$/, async function (pageHeader: string) {
    await expect(async () => {
        const headerText = await poManager.getQuotePage().pageHeader.textContent();
        expect(headerText?.trim()).toBe(pageHeader);
    }).toPass({
        intervals: [1_000, 2_000, 10_000],
        timeout: 60_000
    });
});

When('I select Payment Method', async function () {
    await poManager.getCommonPage().getLabel(parsedJsonData.Payment_Method).click();
    await poManager.getCommonPage().getLabel(parsedJsonData.Payment_Freq).click();
});

Then(/^I save quote reference number for (.+)$/, async function (scenarioID) {
    const success_msg = await poManager.getQuotePage().quoteRef.textContent()
    let quote_ref: any;
    if (success_msg) {
        quote_ref = success_msg.split('-')[1].trim();
    }
    await writeToInputFile(quote_ref, 'Quote_Ref_No', scenarioID)
});