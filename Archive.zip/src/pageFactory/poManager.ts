import { Page } from '@playwright/test';
import { HomePage } from "./pageObjects/AXA/homePage";
import { QuotePage } from "./pageObjects/AXA/quotePage";
import { CommonPage } from './pageObjects/Common/commonPage';
import { CreateCasePage } from './pageObjects/Salesforce/createCase';
import { SFLoginPage } from './pageObjects/Salesforce/loginPage';

export class POManager {

    readonly homePage: HomePage;
    readonly quotePage: QuotePage;
    readonly commonPage: CommonPage;
    readonly createCasepage: CreateCasePage;
    readonly sfLoginPage: SFLoginPage;

    constructor(page: Page) {
        this.homePage = new HomePage(page);
        this.quotePage = new QuotePage(page);
        this.commonPage = new CommonPage(page);
        this.createCasepage = new CreateCasePage(page);
        this.sfLoginPage = new SFLoginPage(page);
    }

    getHomePage() {
        return this.homePage;
    }

    getQuotePage() {
        return this.quotePage;
    }

    getCommonPage() {
        return this.commonPage;
    }

    getCreateCasePage() {
        return this.createCasepage;
    }

    getSFLoginPage() {
        return this.sfLoginPage;
    }
}