import { type Locator, type Page } from '@playwright/test';

export class QuotePage {
    readonly page: Page;
    readonly title: Locator;
    readonly firstName: Locator;
    readonly lastName: Locator;
    readonly birthDay: Locator;
    readonly birthMonth: Locator;
    readonly birthYear: Locator;
    readonly emailAddress: Locator;
    readonly mobile: Locator;
    readonly postCode: Locator;
    readonly searchedAddress: Locator;
    readonly county: Locator;
    readonly coverDay: Locator;
    readonly coverMonth: Locator;
    readonly coverYear: Locator;
    readonly authID: Locator;
    readonly pageHeader: Locator;
    readonly quoteRef: Locator;

    constructor(page: Page) {
        this.page = page
        this.title = page.locator("//select[contains(@id,'title')]");
        this.firstName = page.locator("//input[contains(@id,'forename')]");
        this.lastName = page.locator("//input[contains(@id,'surname')]");
        this.birthDay = page.locator("//select[contains(@id,'birthDay')]");
        this.birthMonth = page.locator("//select[contains(@id,'birthMonth')]");
        this.birthYear = page.locator("//select[contains(@id,'birthYear')]");
        this.emailAddress = page.locator("//input[contains(@id,'email')]");
        this.mobile = page.locator("//input[contains(@id,'mobileNumber')]");
        this.postCode = page.locator("//input[contains(@id,'postcode-input')]");
        this.searchedAddress = page.locator("//select[contains(@id,'address-select')]");
        this.county = page.locator("//input[@id='county']");
        this.coverDay = page.locator("//select[contains(@id,'coverDay')]");
        this.coverMonth = page.locator("//select[contains(@id,'coverMonth')]");
        this.coverYear = page.locator("//select[contains(@id,'coverYear')]");
        this.authID = page.locator(`//input[@id='authorisation']`);
        this.pageHeader = page.locator(`//h1`);
        this.quoteRef = page.locator("//p[contains(.,'Please call us now')]");
    }

    medicalCondition(answer: any) {
        return this.page.locator(`//input[@id='previousMedicalConditions${answer}']`);
    }

    tobaccoUse(answer: any) {
        return this.page.locator(`//input[contains(@id,'tobaccoProducts${answer}')]`);
    }
}