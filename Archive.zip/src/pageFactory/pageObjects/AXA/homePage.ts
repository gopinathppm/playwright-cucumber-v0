import { type Locator, type Page } from '@playwright/test';

export class HomePage {
    readonly page: Page;
    readonly healthInsuranceQuote: Locator;
    readonly carInsuranceQuote: Locator;

    constructor(page: Page) {
        this.page = page;
        this.healthInsuranceQuote = page.locator("//a[contains(@id,'115-health-insurance-quote-cta')]");
        this.carInsuranceQuote = page.locator("//a[contains(@id,'100-car-insurance-quote-cta')]");
    }
}