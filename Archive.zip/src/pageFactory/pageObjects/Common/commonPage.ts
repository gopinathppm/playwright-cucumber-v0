import { type Locator, type Page } from '@playwright/test';

export class CommonPage {
    readonly page: Page;

    constructor(page: Page) {
        this.page = page
    }

    getButton(buttonName: string) {
        return this.page.locator(`//button[contains(., '${buttonName}')]`);
    }

    getLabel(labelName: string) {
        return this.page.locator(`//label[contains(., '${labelName}')]`);
    }
}