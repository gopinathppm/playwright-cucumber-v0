import { type Locator, type Page } from '@playwright/test';

export class SFLoginPage {
    readonly page: Page;
    readonly userName: Locator;
    readonly password: Locator;
    readonly login: Locator;

    constructor(page: Page) {
        this.page = page;
        this.userName = page.locator("//*[@name='username']");
        this.password = page.locator("//*[@name='pw']");
        this.login = page.locator("//*[@name='Login']");
    }

    welcomeMessage(text: string) {
        return this.page.locator(`span:has-text('${text}')`)
    }
}