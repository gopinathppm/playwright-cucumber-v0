import { type Locator, type Page } from '@playwright/test';

export class CreateCasePage {
    readonly page: Page;
    readonly appLauncher: Locator;
    readonly searchBox: Locator;
    readonly searchText: Locator;
    readonly selectNewcase: Locator;
    readonly searchContacts: Locator;
    readonly getButton: Locator;

    constructor(page: Page) {
        this.page = page;
        this.appLauncher = page.locator("//*[@title='App Launcher']");
        this.searchBox = page.locator("//*[@placeholder='Search apps and items...']");
        this.searchText = page.locator(".slds-size_small");
        this.selectNewcase = page.locator('(//*[@title="New"])[1]');
        this.searchContacts = page.locator('//*[@placeholder = "Search Contacts..."]');
        this.getButton = page.locator("(//button[contains(text(),'Save')])[3]");
    }

    errorMessage(text: String) {
        return this.page.locator(`(//*[contains(text(),'${text}')])[2]`);
    }
}