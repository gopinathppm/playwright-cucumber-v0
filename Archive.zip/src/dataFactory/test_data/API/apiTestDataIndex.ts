let CREATE_NEW_ITEM = require('./requestPayloads/ADDNEWDATA.json')


export { CREATE_NEW_ITEM };

