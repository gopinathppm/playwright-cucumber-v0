import * as path from 'path';
const envVariable = `${process.env.NODE_ENV}`;

function generateConfig(envVariable: string) {
    return {
        envVariable,
        inputDataFilePath: path.join(process.cwd(), `./src/dataFactory/test_data/functionality.xlsx`),
        jsonDataFilePath: path.join(process.cwd(), `./src/dataFactory/test_data/functionality.json`),
        lockFilePath: path.join(process.cwd(), `./src/dataFactory/test_data/test.lock`),
    };
}

const dataconfig = generateConfig(envVariable);
export { dataconfig };