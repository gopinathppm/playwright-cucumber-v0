import { chromium, firefox, webkit, Browser, BrowserContext, devices } from 'playwright';
import * as dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

export class BrowserFactory {

    // Create a browser context for different environments
    static async createBrowser(
        browserName: string,
        deviceName?: string,
        isBrowserStack: boolean = process.env.IS_BROWSERSTACK === 'true' // Fetch from environment
    ): Promise<BrowserContext> {

        let browser: Browser;
        if (isBrowserStack) {
            return await this.createBSBrowser(browserName, deviceName);
        }

        // Local browser options
        const browserOptions = { headless: false, viewport: null };

        switch (browserName) {
            case 'chromium':
                browser = await chromium.launch(browserOptions); // Launch local Chromium
                break;
            case 'firefox':
                browser = await firefox.launch(browserOptions);
                break;
            case 'webkit':
                browser = await webkit.launch(browserOptions);
                break;
            default:
                throw new Error('Unsupported browser: ' + browserName);
        }

        // Set device emulation if provided
        const contextOptions = deviceName ? { ...devices[deviceName] } : {};
        return await browser.newContext(contextOptions);
    }

    // BrowserStack Browser connection
    static async createBSBrowser(
        browserName: string,
        deviceName?: string
    ): Promise<BrowserContext> {
        const capabilities = {
            browser: "playwright-" + browserName,
            os: 'Windows',
            os_version: '11',
            name: 'Playwright Test',
            build: 'Playwright BrowserStack Build',
            'browserstack.username': process.env.BROWSERSTACK_USERNAME || 'your_browserstack_username',
            'browserstack.accessKey': process.env.BROWSERSTACK_ACCESS_KEY || 'your_browserstack_access_key'
        };

        const BS_GRID_URL = `wss://cdp.browserstack.com/playwright?caps=${encodeURIComponent(
            JSON.stringify(capabilities)
        )}`;

        // Connect to BrowserStack's WebSocket using chromium.connect
        const browser = await chromium.connect(BS_GRID_URL);
        const contextOptions = deviceName ? devices[deviceName] : {};
        return await browser.newContext(contextOptions);
    }
}