import { dataconfig } from "./dataConfig";

function getBaseUrl(): string {
    let baseUrl: string;

    switch (dataconfig.envVariable) {
        case 'DEV':
            baseUrl = 'https://www.royallondon.com/';
            break;
        case 'SIT':
            baseUrl = 'https://login.salesforce.com/?locale=uk';
            break;
        case 'UAT':
            baseUrl = 'https://uat.axa.co.uk';
            break;
        case 'PROD':
            baseUrl = 'https://www.axa.co.uk';
            break;
        default:
            baseUrl = 'https://www.google.co.uk';
    }
    return baseUrl;
}

export { getBaseUrl };