import { APIRequestContext, request, APIResponse } from '@playwright/test';

class MakeApiRequests {
    private context?: APIRequestContext;

    // Initialize the request context only once
    private async initContext(): Promise<APIRequestContext> {
        if (!this.context) {
            this.context = await request.newContext();
        }
        return this.context;
    }

    // Make POST request with proper error handling
    async makePostRequest(authRequestBody: Record<string, any>, url: string, headers: Record<string, string>): Promise<APIResponse> {
        try {
            const context = await this.initContext();
            const response: APIResponse = await context.post(url, {
                headers: headers,
                data: authRequestBody
            });

            // Log the status code and response body
            // console.log(`Status: ${response.status()}`);

            // Assuming response is in JSON format, we parse and log it
            // const responseBody = await response.json();
            // console.log('Response Body:', responseBody);
            return response
        } catch (err: unknown) {
            const error = err as Error;
            console.error("Error while processing POST request", error.message);
            throw error
        }
    }

    async makeGetRequest(url: string, headers: Record<string, string>): Promise<APIResponse> {
        try {
            const context = await this.initContext();
            const response: APIResponse = await context.get(url, {
                headers: headers
            });
            return response;
        } catch (err: unknown) {
            const error = err as Error;
            console.error("Error while processing GET request", error.message);
            throw error
        }
    }
}

export default new MakeApiRequests();
