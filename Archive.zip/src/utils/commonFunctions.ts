import * as ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';
import logger from '../../logger';
import { dataconfig } from '../configs/dataConfig';
import { BrowserContext, Page, Locator } from 'playwright';
import AxeBuilder from '@axe-core/playwright';
import { functionalityName } from './excelOperation';

const lockfile = require('lockfile');

export let globalJsonData: any;

export async function convertExcelToJson(filePath: string): Promise<any> {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);

    // Create a json data object
    const worksheet = workbook.worksheets[0];
    const jsonData: { [key: string]: any } = {};

    // Loop through InputData excel sheet to fetch data for Json Object
    for (let col = 2; col <= worksheet.columnCount; col++) {
        const scenarioCell = worksheet.getCell(1, col); // Get cell from row 1 and current column
        const scenario = scenarioCell.value?.toString(); // Use the value of the cell as the scenario key
        if (scenario) {
            const scenarioData: { [key: string]: any } = {};

            // Write value of column on as Key and Column 2 onwards in Value
            for (let row = 2; row <= worksheet.rowCount; row++) {
                const headerCell = worksheet.getCell(row, 1);
                const valueCell = worksheet.getCell(row, col);
                const header = headerCell.value?.toString();
                let value = valueCell.value;
                if (value === null) {
                    value = "";
                }
                // Check if the cell has a shared formula
                if (valueCell.formula) {
                    // If it's a shared formula, fetch the calculated value
                    value = valueCell.result;
                }

                if (header && value !== undefined) {
                    scenarioData[header] = value;
                }
            }
            jsonData[scenario] = scenarioData;
        }
    }
    return jsonData;
};

export async function writeToInputFile(output: string, fieldName: any, Scenario: string): Promise<void> {
    await acquireLock(dataconfig.lockFilePath);
    let inputWorkbook = new ExcelJS.Workbook();
    let inputDataFilePath = (dataconfig.inputDataFilePath).replace('functionality', `${functionalityName}`)
    await inputWorkbook.xlsx.readFile(inputDataFilePath);
    const inputWorksheet = inputWorkbook.worksheets[0];
    let column: any = null;
    let row: any = null;

    for (let i = 1; i <= inputWorksheet.rowCount; i++) {
        const cellValue1 = inputWorksheet.getCell(i, 1).value?.toString();
        if (cellValue1 === fieldName) {
            row = i;
            for (let j = 1; j <= inputWorksheet.columnCount; j++) {
                const cellValue2 = inputWorksheet.getCell(1, j).value?.toString();
                if (cellValue2 === Scenario) {
                    column = j;
                    break;
                }
            }
            break;
        }
    }

    if (row && column) {
        inputWorksheet.getCell(row, column).value = output;
        await inputWorkbook.xlsx.writeFile(inputDataFilePath);
        logger.info(`Writing output "${output}" to row ${row}, column ${column}`);
    } else {
        console.error('Could not find matching row/column for fieldName or Scenario');
    }
    await releaseLock(dataconfig.lockFilePath)
};

export async function acquireLock(lockFilePath: any) {
    return new Promise<void>((resolve) => {
        const tryAcquireLock = () => {
            lockfile.lock(lockFilePath, { retries: Infinity, retryWait: 100 }, (err: any) => {
                if (err) {
                    logger.info(`Attempt to acquire lock failed. Retrying...`);
                    tryAcquireLock();
                } else {
                    logger.info("Lock acquired successfully.");
                    resolve();
                }
            });
        };

        tryAcquireLock();
    });
}

export async function releaseLock(lockFilePath: any) {
    return new Promise<void>((resolve, reject) => {
        lockfile.unlock(lockFilePath, (err: any) => {
            if (err) {
                reject(err);
            } else {
                logger.info("Lock released successfully.");
                resolve();
            }
        });
    });
};

export async function clickAndWaitForNewPage(page: Page, context: BrowserContext, locator: Locator): Promise<Page> {
    await locator.waitFor({ state: 'visible' });
    const [newPage] = await Promise.all([
        context.waitForEvent('page'),
        locator.click()
    ]);
    await newPage.waitForLoadState();
    return newPage;
};

export async function validateAccessibility(page: Page, wcagTags: string[]) {
    const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(wcagTags)
        .analyze();

    const violationCount = accessibilityScanResults.violations.length;
    if (violationCount > 0) {
        console.log(`Found ${violationCount} violations.`);
    } else {
        console.log('No violations found.');
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '_');
    const fileName = `report_${timestamp}.html`;
    const filePath = path.join('./reports/Accessibility', fileName);

    if (!fs.existsSync('reports/Accessibility')) {
        fs.mkdirSync('reports/Accessibility');
        console.log('Created Accessibility directory.');
    }

    const browserUrl = page.title();
    const htmlContent = generateHtmlReport(accessibilityScanResults, await browserUrl); // Generate HTML report
    fs.writeFileSync(filePath, htmlContent);
    console.log('Accessibility Results have been saved to:', filePath);
};

export function generateHtmlReport(result: any, url: string): string {
    const violations = result?.violations || [];
    const htmlTemplate = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Accessibility Results</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background-color: #f8f9fa;
                    margin: 0;
                    padding: 0;
                }
                h1 {
                    color: #007bff;
                    background-color: #f8f9fa;
                    padding: 20px;
                    margin: 0;
                    text-align: center;
                    border-bottom: 2px solid #ccc;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin-top: 20px;
                    background-color: #fff;
                    border: 1px solid #dcdcdc;
                    border-radius: 8px;
                    overflow: hidden;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
                }
                th, td {
                    border: 1px solid #dcdcdc;
                    padding: 15px;
                    text-align: left;
                }
                th {
                    background-color: #007bff;
                    color: white;
                }
                td {
                    background-color: #f8f9fa;
                }
                ul {
                    list-style: none;
                    margin: 0;
                    padding: 0;
                }
                li {
                    margin-bottom: 10px;
                }
                a {
                    color: #007bff;
                    text-decoration: none;
                    cursor: pointer;
                }
                a:hover {
                    text-decoration: underline;
                }
                img {
                    max-width: 100%;
                    height: auto;
                }
            </style>
        </head>
        <body>
            <h1>Accessibility Results</h1>
            <p style="text-align: center; margin-top: 10px;">URL: <strong>${url}</strong></p>
            <table>
                <tr>
                    <th>Rule</th>
                    <th>Description</th>
                    <th>Impact</th>
                    <th>Help</th>
                    <th>Nodes with Issues</th>
                    <th>Guideline</th>
                </tr>
                ${violations.length > 0 ? violations.map((violation: any, index: number) => `
                    <tr>
                        <td>${violation.id}</td>
                        <td>${violation.description}</td>
                        <td>${violation.impact}</td>
                        <td>${violation.help}</td>
                        <td>
                            <a href="#" class="nodes-link" data-target="nodes_${index}" data-text="View">View Nodes with Issues</a>
                        </td>
                        <td>${violation.helpUrl ? `<a href="${violation.helpUrl}" target="_blank">More Information</a>` : ''}</td>
                    </tr>
                    <tr id="nodes_${index}" class="nodes-section" style="display:none;">
                        <td colspan="6">
                            <ul>
                                ${violation.nodes.map((node: any) => `
                                    <li>
                                        <strong>Element Location:</strong> ${node.target}
                                        <br>
                                        ${node.html}
                                    </li>
                                `).join('')}
                            </ul>
                        </td>
                    </tr>
                `).join('') : `
                    <tr>
                        <td colspan="6" style="text-align: center;">No accessibility violations found.</td>
                    </tr>
                `}
            </table>
            <img src="https://example.com/your-logo.png" alt="Your Company Logo" style="display: block; margin: 20px auto;">
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    var currentlyOpenedSection = null;

                    var nodesLinks = document.querySelectorAll('.nodes-link');
                    nodesLinks.forEach(function(link) {
                        link.addEventListener("click", function(e) {
                            e.preventDefault();
                            var targetId = this.getAttribute('data-target');
                            var targetElement = document.getElementById(targetId);
                            if (targetElement) {
                                // Close the currently opened section
                                if (currentlyOpenedSection && currentlyOpenedSection !== targetElement) {
                                    currentlyOpenedSection.style.display = 'none';
                                    var correspondingLink = document.querySelector('[data-target="' + currentlyOpenedSection.id + '"]');
                                    if (correspondingLink) {
                                        correspondingLink.innerText = 'View Nodes with Issues';
                                    }
                                }

                                // Toggle visibility of the selected section
                                var displayStyle = targetElement.style.display;
                                targetElement.style.display = (displayStyle === 'none' || displayStyle === '') ? 'table-row' : 'none';

                                // Change the text of the clicked link based on the visibility state
                                var newText = (displayStyle === 'none' || displayStyle === '') ? 'Hide Nodes with Issues' : 'View Nodes with Issues';
                                this.innerText = newText;

                                // Update the reference to the currently opened section
                                currentlyOpenedSection = (displayStyle === 'none' || displayStyle === '') ? null : targetElement;

                                // Scroll to the selected section if it's being displayed
                                if (targetElement.style.display !== 'none') {
                                    targetElement.scrollIntoView({ behavior: 'smooth' });
                                }
                            }
                        });
                    });
                });
            </script>
        </body>
        </html>
    `;
    return htmlTemplate;
};

export function generateFinalHtmlReport() {
    const reportDirectory = 'reports/Accessibility';
    const finalFilePath = path.join(reportDirectory, 'Final_Accessibility_Report.html');

    // Fetch all HTML report files from the Accessibility folder
    const allReports = fs.readdirSync(reportDirectory)
        .filter(file => file.endsWith('.html') && file.startsWith('report_'))
        .map(file => path.join(reportDirectory, file));

    if (allReports.length === 0) {
        console.log('No individual reports found in the Accessibility folder.');
        return;
    }

    const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Final Accessibility Report</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background-color: #f8f9fa;
                    margin: 0;
                    padding: 0;
                }
                h1 {
                    color: #007bff;
                    background-color: #f8f9fa;
                    padding: 20px;
                    margin: 0;
                    text-align: center;
                    border-bottom: 2px solid #ccc;
                }
                table {
                    border-collapse: collapse;
                    width: 80%;
                    margin: 20px auto;
                    background-color: #fff;
                    border: 2px solid #007bff;
                    border-radius: 8px;
                    overflow: hidden;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
                }
                th, td {
                    border: 1px solid #007bff;
                    padding: 15px;
                    text-align: center;
                }
                th {
                    background-color: #007bff;
                    color: white;
                }
                td {
                    background-color: #f8f9fa;
                }
                a {
                    color: #007bff;
                    text-decoration: none;
                    cursor: pointer;
                }
                a:hover {
                    text-decoration: underline;
                }
            </style>
        </head>
        <body>
            <h1>Final Accessibility Report</h1>
            <table>
                <tr>
                    <th>Browser URL</th>
                    <th>Execution Timestamp</th>
                    <th>Individual Report Link</th>
                </tr>
                ${allReports.map(reportPath => {
        const timestamp = path.basename(reportPath).replace('report_', '').replace('.html', '');
        const relativePath = path.relative(reportDirectory, reportPath).replace(/\\/g, '/');

        // Read the content of the individual report
        const baseReportContent = fs.readFileSync(reportPath, 'utf8');

        // Extract the browser URL from the individual report
        const browserUrlMatch = baseReportContent.match(/URL:\s*<strong>(.*?)<\/strong>/i);
        const browserUrl = browserUrlMatch ? browserUrlMatch[1] : 'Unknown URL';

        return `
                        <tr>
                            <td>${browserUrl}</td>
                            <td>${timestamp}</td>
                            <td><a href="${relativePath}" target="_blank">View Report</a></td>
                        </tr>`;
    }).join('')}
            </table>
        </body>
        </html>
    `;

    // Write the final report to a file
    fs.writeFileSync(finalFilePath, htmlContent);
    console.log('Final Accessibility Report has been saved to:', finalFilePath);
};