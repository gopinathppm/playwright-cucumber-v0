import { Then } from '@cucumber/cucumber';
import { convertExcelToJson, globalJsonData } from './commonFunctions';
import * as fs from 'fs';
import logger from '../../logger';
import { dataconfig } from '../configs/dataConfig';

export let jsonContent: any;
export let jsonObject: any;
export let ScenarioNumber: any;
export let functionalityName: any;
let parsedJsonData: typeof globalJsonData;

Then(/^I convert (.+) Excel file to JSON for testData reading$/, async function (functionality) {
    functionalityName = functionality;

    let inputDataFilePath = (dataconfig.inputDataFilePath).replace('functionality', `${functionalityName}`)
    let jsonDataFilePath = (dataconfig.jsonDataFilePath).replace('functionality', `${functionalityName}`)
    logger.info(`${functionality} input path:`, inputDataFilePath)
    await convertExcelToJson(inputDataFilePath).then((jsonData) => {
        jsonContent = JSON.stringify(jsonData, null, 2);
        fs.writeFileSync(jsonDataFilePath, jsonContent);
        logger.info('Data has been converted from Excel to JSON and written to TestData file');
    }).catch((error) => {
        logger.error('Error converting Excel to JSON:', error);
        throw error;
    });
});

Then(/^I read (.+) data from the (.+)$/, async function (Scenario, functionality) {
    ScenarioNumber = Scenario;
    functionalityName = functionality;
    let jsonDataFilePath = (dataconfig.jsonDataFilePath).replace('functionality', `${functionalityName}`)
    jsonObject = JSON.parse(fs.readFileSync(jsonDataFilePath, 'utf-8'));
    parsedJsonData = jsonObject[Scenario];
    if (!parsedJsonData) {
        logger.error('TestData JSON is not available or your scenario data is not in the JSON file');
        throw new Error('TestData JSON is not available');
    }
});

export { parsedJsonData };